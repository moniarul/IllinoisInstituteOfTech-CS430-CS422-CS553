## Programming Assignment 2a
#### Runnimg Shared Memory (1VM 2GB) MySort
 
- cd /exports/home/schatterjee/cs553-pa2a/
- sbatch mysort2GB.slurm
- It will run the program in compute node and at the end will run valsort as well
- Out put will be stored at /exports/home/schatterjee/cs553-pa2a/mysort2gb.log

#### Runnimg Shared Memory (1VM 20GB) MySort
 
- cd /exports/home/schatterjee/cs553-pa2a/
- sbatch mysort20GB.slurm
- It will run the program in compute node and at the end will run valsort as well
- Out put will be stored at /exports/home/schatterjee/cs553-pa2a/mysort20gb.log

#### Runnimg Linsort (1VM 2GB) MySort
 
- cd /exports/home/schatterjee/cs553-pa2a/
- sbatch linsort2GB.slurm
- It will run the sort in compute node and at the end will run valsort as well.
- Out put will be stored at /exports/home/schatterjee/cs553-pa2a/linsort2gb.log

#### Runnimg Linsort (1VM 20GB) MySort
 
- cd /exports/home/schatterjee/cs553-pa2a/
- sbatch linsort20GB.slurm
- It will run the sort in compute node and at the end will run valsort as well.
- Out put will be stored at /exports/home/schatterjee/cs553-pa2a/linsort20gb.log