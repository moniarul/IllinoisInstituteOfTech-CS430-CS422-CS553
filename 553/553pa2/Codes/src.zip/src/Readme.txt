> To Run hadoopsort8GB

1) cd /exports/home/schatterjee/cs553-pa2b
2) sbatch hadoopsort8GB.slurm

> To Run hadoopsort20GB

1) cd /exports/home/schatterjee/cs553-pa2b
2) sbatch hadoopsort20GB.slurm


> To Run hadoopsort80GB

1) cd /exports/home/schatterjee/cs553-pa2b
2) sbatch hadoopsort80GB.slurm


> To Run sparksort8GB

1) cd /exports/home/schatterjee/cs553-pa2b
2) sbatch sparksort8GB.slurm

> To Run sparksort20GB

1) cd /exports/home/schatterjee/cs553-pa2b
2) sbatch sparksort20GB.slurm


> To Run sparksort80GB

1) cd /exports/home/schatterjee/cs553-pa2b
2) sbatch sparksort80GB.slurm
